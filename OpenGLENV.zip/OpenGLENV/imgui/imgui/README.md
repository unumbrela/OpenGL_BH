使用流程
1. 把imgui文件夹拖入项目根目录
2. 把GetImgui.h添加到项目的头文件中
3. 根据示例main.cpp进行修改